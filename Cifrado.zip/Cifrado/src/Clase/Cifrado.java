/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clase;

import Vista.frmCifrado;
/**
 *
 * @author liboriocastanedavalencia
 */
public class Cifrado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frmCifrado cfr = new frmCifrado();
        cfr.setLocationRelativeTo(null);
        cfr.setVisible(true);
    }

}
